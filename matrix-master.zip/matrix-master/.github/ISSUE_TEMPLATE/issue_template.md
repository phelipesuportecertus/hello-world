---
name: Create an issue
about: Create an issue to help us improve
title: ''
labels: ''
assignees: ''
---

<!--- Provide a general summary of the issue in the Title above -->
<!--- Do not forget to inform the issue's tags -->
<!--- kind: (bug / tech debt / ux debt), priority: (low / medium / high) -->

## Description
<!--- Provide a detailed description of the change or addition you are proposing -->

### Steps to Reproduce
<!--- Provide a link to a live example, or an unambiguous set of steps to -->
<!--- reproduce this bug. Include code to reproduce, if relevant -->
1. First step
1. Second step
1.

### Expected Behavior
<!--- Tell us clearly what should happen -->
- expected behavior

### Current Behavior
<!--- Tell us what happens instead of the expected behavior. You can use screenshot or gifs to help in understanding  -->
- current behavior

### Possible Solution
<!--- Not obligatory, but suggest a fix/reason for the bug, -->
- possible solution
