module.exports = {
  require: ["@babel/register", "jsdom-global/register", "./test/setup.js"]
};
