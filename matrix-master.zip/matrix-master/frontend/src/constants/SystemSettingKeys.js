const SystemSettingKeys = {
  notificationDisabled: "notificationDisabled"
};

export default SystemSettingKeys;
