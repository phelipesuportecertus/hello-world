import React from "react";
import { render } from "react-dom";
import { Login } from "./pages/login";

render(<Login />, document.querySelector("#application"));
