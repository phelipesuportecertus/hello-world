import React from "react";

export const Title = () => (
  <div className="row justify-content-center align-items-center p-3">
    <h5 className="text-center">Work everywhere. Stay Together</h5>
  </div>
);
