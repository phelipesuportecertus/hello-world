module.exports = {
  env: {
    node: true
  },
  rules: {
    "no-unused-expressions": ["off"]
  }
};
