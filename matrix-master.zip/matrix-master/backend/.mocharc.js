module.exports = {
  require: ["@babel/register"]
};
